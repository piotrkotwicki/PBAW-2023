<?php
/* Smarty version 3.1.30, created on 2023-04-26 20:51:59
  from "C:\xampp\htdocs\html5up-landed\templates\main.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_644972cf0ee343_48379339',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cf8c53580fa964a5d08e3ed512d184a127df753c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\html5up-landed\\templates\\main.html',
      1 => 1682395693,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_644972cf0ee343_48379339 (Smarty_Internal_Template $_smarty_tpl) {
?>


<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
<head>
	<title>Kalkulator Kredytowy</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="assets/css/main.css" />
	<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="page-wrapper">

	<!-- Header -->
	<header id="header">
		<h1 id="logo"><a>Kalkulator Kredytowy</a></h1>
		<nav id="nav">
			<ul>
				<li>
					<a href="#">Nawigacja</a>
					<ul>
						<li><a href="#app_top">Góra strony</a></li>
						<li><a href="#app_content">Idź do formularza</a></li>
					</ul>
				</li>
				<li><a href="elements.html">Odśwież</a></li>
			</ul>
		</nav>
	</header>

	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<header class="major">
				<h2>Kalkulator Kredytowy</h2>
				<p>Autor: Piotr Kotwicki</p>
			</header>

			<!-- Text -->
			<section>
				<h3>O stronie</h3>
				<p>Kalkulator kredytowy w wersji obiektowej</p>
				<a  class="pure-button pure-button-primary" href="#app_content">Idź do formularza</a>
				<hr />







				<!-- Form -->
				<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/app/calc.php" method="post">
					<fieldset>

						<label for="kwotaPozyczki">Kwota pożyczki: </label>
						<input id="kwotaPozyczki" type="text" placeholder="kwota pożyczki" name="kwotaPozyczki" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->kwotaPozyczki;?>
">
						<label for="iloscMiesiecy">Czas trwania w miesiącach: </label>
						<input id="iloscMiesiecy" type="text" placeholder="ilość miesięcy" name="iloscMiesiecy" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->iloscMiesiecy;?>
">
						<label for="oprocentowanie">Oprocentowanie: </label>
						<input id="oprocentowanie" type="text" placeholder="wartość oprocentowania" name="oprocentowanie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->oprocentowanie;?>
">

						<button type="submit" class="pure-button">Oblicz</button>
					</fieldset>
				</form>


		</div>
	</div>

	<!-- Footer -->
	<footer id="footer">
		<ul class="copyright">
			<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
		</ul>
	</footer>

</div>

<!-- Scripts -->
<?php echo '<script'; ?>
 src="assets/js/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/jquery.scrolly.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/jquery.dropotron.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/jquery.scrollex.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/browser.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/util.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="assets/js/main.js"><?php echo '</script'; ?>
>

</body>
</html><?php }
}
