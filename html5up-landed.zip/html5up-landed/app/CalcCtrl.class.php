<?php
// W skrypcie definicji kontrolera nie trzeba dołączać problematycznego skryptu config.php,
// ponieważ będzie on użyty w miejscach, gdzie config.php zostanie już wywołany.

require_once $conf->root_path.'/lib/smarty/libs/Smarty.class.php';
require_once $conf->root_path.'/lib/Messages.class.php';
require_once $conf->root_path.'/app/CalcForm.class.php';
require_once $conf->root_path.'/app/CalcResult.class.php';

/** Kontroler kalkulatora
 * @author Piotr Kotwicki
 *
 */
class CalcCtrl {

	private $msgs;   //wiadomości dla widoku
	private $form;   //dane formularza (do obliczeń i dla widoku)
	private $result; //inne dane dla widoku
	

	/** 
	 * Konstruktor - inicjalizacja właściwości
	 */
	public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->msgs = new Messages();
		$this->form = new CalcForm();
		$this->result = new CalcResult();
	}
	
	/** 
	 * Pobranie parametrów
	 */
	public function getParams(){
		$this->form->kwotaPozyczki = isset($_REQUEST ['kwotaPozyczki']) ? $_REQUEST ['kwotaPozyczki'] : null;
		$this->form->iloscMiesiecy = isset($_REQUEST ['iloscMiesiecy']) ? $_REQUEST ['iloscMiesiecy'] : null;
        $this->form->oprocentowanie = isset($_REQUEST ['oprocentowanie']) ? $_REQUEST ['oprocentowanie'] : null;
	}
	
	/** 
	 * Walidacja parametrów
	 * @return true jeśli brak błedów, false w przeciwnym wypadku 
	 */
	public function validate() {
		// sprawdzenie, czy parametry zostały przekazane
		if (! (isset ( $this->form->kwotaPozyczki ) && isset ( $this->form->iloscMiesiecy ) && isset ( $this->form->oprocentowanie ))) {
			// sytuacja wystąpi kiedy np. kontroler zostanie wywołany bezpośrednio - nie z formularza
			return false; //zakończ walidację z błędem
		} 
		
		// sprawdzenie, czy potrzebne wartości zostały przekazane
		if ($this->form->kwotaPozyczki == "") {
			$this->msgs->addError('Nie podano kwoty pożyczki');
		}
		if ($this->form->iloscMiesiecy == "") {
			$this->msgs->addError('Nie podano czasu trwania');
		}
        if ($this->form->oprocentowanie == "") {
            $this->msgs->addError('Nie podano wysokości oprocentowania');
        }
		
		// nie ma sensu walidować dalej gdy brak parametrów
		if (! $this->msgs->isError()) {
			
			// sprawdzenie, czy $x i $y są liczbami całkowitymi
			if (! is_numeric ( $this->form->kwotaPozyczki )) {
				$this->msgs->addError('Podana kwota pożyczki nie jest liczbą całkowitą');
			}
			
			if (! is_numeric ( $this->form->iloscMiesiecy )) {
				$this->msgs->addError('Podany czas trwania w miesiącach nie jest liczbą całkowitą');
			}
            if (! is_numeric ( $this->form->oprocentowanie )) {
                $this->msgs->addError('Podana wartość oprocentowania nie jest liczbą całkowitą');
            }
		}
		
		return ! $this->msgs->isError();
	}
	
	/** 
	 * Pobranie wartości, walidacja, obliczenie i wyświetlenie
	 */
	public function process(){

		$this->getparams();
		
		if ($this->validate()) {
				
			//konwersja parametrów na int
			$this->form->kwotaPozyczki = intval($this->form->kwotaPozyczki);
			$this->form->iloscMiesiecy = intval($this->form->iloscMiesiecy);
            $this->form->oprocentowanie = intval($this->form->oprocentowanie);

            $this->msgs->addInfo('Parametry poprawne.');
				
			//wykonanie operacji
            $this->result->result=($this->form->kwotaPozyczki + ($this->form->kwotaPozyczki * ( $this->form->oprocentowanie/100)))/$this->form->iloscMiesiecy;


            $this->msgs->addInfo('Wykonano obliczenia.');
		}
		
		$this->generateView();
	}
	
	
	/**
	 * Wygenerowanie widoku
	 */
	public function generateView(){
		global $conf;
		
		$smarty = new Smarty();
		$smarty->assign('conf',$conf);
		
		$smarty->assign('page_title','Kalkulator kredytowy by Piotr Kotwicki');
		$smarty->assign('page_description','Wersja obiektowa');
		$smarty->assign('page_header','Obiekty w PHP');
				
		
		
		$smarty->assign('msgs',$this->msgs);
		$smarty->assign('form',$this->form);
		$smarty->assign('res',$this->result);
		
		$smarty->display($conf->root_path.'/app/Calc_View.html');
	}
}
