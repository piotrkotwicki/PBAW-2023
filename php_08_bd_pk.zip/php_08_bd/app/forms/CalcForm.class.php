<?php

namespace app\forms;

class CalcForm {
    public $id;
    public $kwotaPozyczki;
    public $iloscMiesiecy;
    public $oprocentowanie;
} 