<?php

namespace app\controllers;

use app\forms\CalcForm;
use app\transfer\CalcResult;
use PDOException;
class CalcCtrl {

    private $form;
    private $result;
    private $records;

    public function __construct(){
		$this->form = new CalcForm();
		$this->result = new CalcResult();
    }

    public function getParams(){
        $this->form->kwotaPozyczki = getFromRequest('kwotaPozyczki');
        $this->form->iloscMiesiecy = getFromRequest('iloscMiesiecy');
        $this->form->oprocentowanie = getFromRequest('oprocentowanie');
    }

    public function validate(){

    // sprawdzenie, czy parametry zostały przekazane
    if (! (isset ( $this->form->kwotaPozyczki ) && isset ( $this->form->iloscMiesiecy ) && isset ( $this->form->oprocentowanie ))) {
        // sytuacja wystąpi kiedy np. kontroler zostanie wywołany bezpośrednio - nie z formularza
        return false;
    }

    // sprawdzenie, czy potrzebne wartości zostały przekazane
    if ($this->form->kwotaPozyczki == "") {
        getMessages()->addError('Nie podano kwoty pożyczki');
    }
    if ($this->form->iloscMiesiecy == "") {
        getMessages()->addError('Nie podano czasu trwania');
    }
    if ($this->form->oprocentowanie == "") {
        getMessages()->addError('Nie podano wysokości oprocentowania');
    }
    // nie ma sensu walidować dalej gdy brak parametrów
    if (! getMessages()->isError()) {

        // sprawdzenie, czy $x i $y są liczbami całkowitymi
        if (! is_numeric ( $this->form->kwotaPozyczki)) {
            getMessages()->addError('Podana kwota pożyczki nie jest liczbą całkowitą');
        }

        if (! is_numeric ( $this->form->iloscMiesiecy )) {
            getMessages()->addError('Podany czas trwania nie jest liczbą całkowitą');
        }
        if (! is_numeric ( $this->form->oprocentowanie )) {
            getMessages()->addError('Podana wartość oprocentowania nie jest liczbą całkowitą');
        }
    }

    return ! getMessages()->isError();
    }

    public function validateEdit() {
            $this->form->id = getFromRequest('id',true,'Błędne wywołanie aplikacji');
            return ! getMessages()->isError();
        }

    public function action_calcCompute(){

        $this->getParams();

        if ($this->validate()) {

            //konwersja parametrów na int
            $this->form->kwotaPozyczki = floatval($this->form->kwotaPozyczki);
            $this->form->iloscMiesiecy = floatval($this->form->iloscMiesiecy);
            $this->form->oprocentowanie = floatval($this->form->oprocentowanie);
            getMessages()->addInfo('Parametry poprawne.');

            //wykonanie operacji
            $this->result->result=($this->form->kwotaPozyczki + ($this->form->kwotaPozyczki * ( $this->form->oprocentowanie/100)))/$this->form->iloscMiesiecy;

            getMessages()->addInfo('Wykonano obliczenia.');
        }

        $this->action_wynikSave();
    }

    public function action_wynikSave(){

		if ($this->validate()) {
			try {
				getDB()->insert("result", [
					"kwotaPozyczki" => $this->form->kwotaPozyczki,
					"iloscMiesiecy" => $this->form->iloscMiesiecy,
					"oprocentowanie" => $this->form->oprocentowanie,
					"result" => $this->result->result
				]);
				getMessages()->addInfo('Pomyślnie zapisano rekord');

			} catch (PDOException $e){
				getMessages()->addError('Wystąpił nieoczekiwany błąd podczas zapisu rekordu');
				if (getConf()->debug) getMessages()->addError($e->getMessage());
			}
			
			$this->action_WynikList();

		} else {
			$this->action_WynikList();
		}
	}
    public function action_WynikList(){
		try{
			$this->records = getDB()->select("result", [
					"idwynik",
					"kwotaPozyczki",
					"iloscMiesiecy",
					"oprocentowanie",
					"result"
				]);
		} catch (PDOException $e){
			getMessages()->addError('Wystąpił błąd podczas pobierania rekordów');
			if (getConf()->debug) getMessages()->addError($e->getMessage());			
        }
        $this->generateView();
	}

	public function action_calcShow(){
		getMessages()->addInfo('Witaj w kalkulatorze');
        $this->action_WynikList();
	}
    
    public function generateView(){
        
		getSmarty()->assign('user',unserialize($_SESSION['user']));
        
        getSmarty()->assign('page_title','Twój Ulubiony Kalkulator ^-^');
        
        getSmarty()->assign('form',$this->form);
        getSmarty()->assign('res',$this->result);
        getSmarty()->assign('record',$this->records);
        
        getSmarty()->display('CalcView.html');
    }
}