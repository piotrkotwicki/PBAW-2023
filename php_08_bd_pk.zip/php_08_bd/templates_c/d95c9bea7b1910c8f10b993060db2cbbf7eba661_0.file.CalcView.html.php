<?php
/* Smarty version 4.3.0, created on 2023-05-31 22:30:29
  from 'E:\dev\xampp\htdocs\paw\php_08_bd\app\views\CalcView.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_6477ae65066fe9_86488220',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd95c9bea7b1910c8f10b993060db2cbbf7eba661' => 
    array (
      0 => 'E:\\dev\\xampp\\htdocs\\paw\\php_08_bd\\app\\views\\CalcView.html',
      1 => 1685565011,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.html' => 1,
  ),
),false)) {
function content_6477ae65066fe9_86488220 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19374849426477ae64db17f3_55976725', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_109603376477ae64db2552_09388901', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.html");
}
/* {block 'footer'} */
class Block_19374849426477ae64db17f3_55976725 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_19374849426477ae64db17f3_55976725',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
przykładowa tresć stopki wpisana do szablonu głównego z szablonu kalkulatora<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_109603376477ae64db2552_09388901 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_109603376477ae64db2552_09388901',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<!-- Main -->
	<div id="app_top" class="wrapper style1" href="#app_top">
	<div class="container">
	<header class="major">
		<h2>Kalkulator Kredytowy</h2>
		<p>Autor: Piotr Kotwicki</p>
	</header>

	<!-- Text -->
	<section id="app_content">
	<h3>O stronie</h3>
	<p>Kalkulator kredytowy w wersji obiektowej</p>
	<a  class="pure-button pure-button-primary" href="#app_content">Idź do formularza</a>
	<hr/>

	<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
calcCompute" method="post">
		<fieldset>
			<label for="kwotaPozyczki">Kwota pożyczki: </label>
			<input id="kwotaPozyczki" type="text" placeholder="kwota pożyczki" name="kwotaPozyczki" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->kwotaPozyczki;?>
">
			<label for="iloscMiesiecy">Czas trwania w miesiącach: </label>
			<input id="iloscMiesiecy" type="text" placeholder="ilość miesięcy" name="iloscMiesiecy" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->iloscMiesiecy;?>
">
			<label for="oprocentowanie">Oprocentowanie: </label>
			<input id="oprocentowanie" type="text" placeholder="wartość oprocentowania" name="oprocentowanie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->oprocentowanie;?>
">

			<button type="submit" class="pure-button">Oblicz</button>
		</fieldset>
	</form>

	<?php $_smarty_tpl->_subTemplateRender('file:messages.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<?php if ((isset($_smarty_tpl->tpl_vars['res']->value->result))) {?>
		<div class="messages inf">
			Wynik: <?php echo $_smarty_tpl->tpl_vars['res']->value->result;?>

		</div>
	<?php }?>

	<table id="tab_people" class="pure-table pure-table-bordered">
		<thead>
			<tr>
				<th>kwotaPozyczki</th>
				<th>iloscMiesiecy</th>
				<th>oprocentowanie</th>
				<th>result</th>
			</tr>
		</thead>
		<tbody>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['record']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
		<tr><td><?php echo $_smarty_tpl->tpl_vars['r']->value["kwotaPozyczki"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["iloscMiesiecy"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["oprocentowanie"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["result"];?>
</td></tr>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</tbody>
		</table>

<?php
}
}
/* {/block 'content'} */
}
