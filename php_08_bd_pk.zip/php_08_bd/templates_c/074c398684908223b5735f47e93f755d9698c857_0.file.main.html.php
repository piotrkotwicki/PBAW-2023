<?php
/* Smarty version 4.3.0, created on 2023-05-31 22:33:24
  from 'C:\xampp\htdocs\php_08_bd\app\views\templates\main.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_6477af14986e64_51098003',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '074c398684908223b5735f47e93f755d9698c857' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_08_bd\\app\\views\\templates\\main.html',
      1 => 1685563368,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6477af14986e64_51098003 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
<head>
	<title>Kalkulator Kredytowy</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/main.css" />
	<noscript><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="page-wrapper">

	<!--	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17412851806477af149840b6_47653972', 'header');
?>
-->
	<!-- Header -->
	<header id="header" >
		<h1 id="logo"><a>Kalkulator Kredytowy</a></h1>
		<nav id="nav">
			<!-- <ul>
				<li>
				<li>użytkownik: <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </li>
				<li>rola: <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>
</li>
				<li><a href="#app_top">Góra strony</a></li>
				<li><a href="#app_content">Idź do formularza</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
">Odśwież</a></li>
				<li><a  href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
				</li>
			</ul> -->
		</nav>
	</header>

	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4264903256477af14985a00_86231545', 'content');
?>


			<!-- Footer -->
			<footer id="footer">
				<ul class="copyright">
					<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
				</ul>
			</footer>
		</div>
	</div>
</div>
</body>
</html>
<?php }
/* {block 'header'} */
class Block_17412851806477af149840b6_47653972 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_17412851806477af149840b6_47653972',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_4264903256477af14985a00_86231545 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_4264903256477af14985a00_86231545',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
}
