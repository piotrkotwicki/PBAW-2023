<?php
/* Smarty version 4.3.0, created on 2023-05-31 22:02:49
  from 'E:\dev\xampp\htdocs\paw\php_08_bd\app\views\templates\main.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_6477a7e91328f2_38900717',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee642f3255fe85cf6006d7720c71fb495a9c8960' => 
    array (
      0 => 'E:\\dev\\xampp\\htdocs\\paw\\php_08_bd\\app\\views\\templates\\main.html',
      1 => 1685563368,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6477a7e91328f2_38900717 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
<head>
	<title>Kalkulator Kredytowy</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/main.css" />
	<noscript><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="page-wrapper">

	<!--	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4432531486477a7e912e694_32069361', 'header');
?>
-->
	<!-- Header -->
	<header id="header" >
		<h1 id="logo"><a>Kalkulator Kredytowy</a></h1>
		<nav id="nav">
			<!-- <ul>
				<li>
				<li>użytkownik: <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </li>
				<li>rola: <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>
</li>
				<li><a href="#app_top">Góra strony</a></li>
				<li><a href="#app_content">Idź do formularza</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
">Odśwież</a></li>
				<li><a  href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
				</li>
			</ul> -->
		</nav>
	</header>

	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8526185596477a7e91321c4_72573622', 'content');
?>


			<!-- Footer -->
			<footer id="footer">
				<ul class="copyright">
					<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
				</ul>
			</footer>
		</div>
	</div>
</div>
</body>
</html>
<?php }
/* {block 'header'} */
class Block_4432531486477a7e912e694_32069361 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_4432531486477a7e912e694_32069361',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_8526185596477a7e91321c4_72573622 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_8526185596477a7e91321c4_72573622',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
}
