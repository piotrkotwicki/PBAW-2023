<?php

namespace app\forms;

class ResultEditForm {
	public $id;
	public $kwotaPozyczki;
	public $iloscMiesiecy;
	public $oprocentowanie;
}