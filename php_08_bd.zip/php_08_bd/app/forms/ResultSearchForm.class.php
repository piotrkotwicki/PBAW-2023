<?php

namespace app\forms;

class ResultSearchForm {
	public $iloscMiesiecy;
} 