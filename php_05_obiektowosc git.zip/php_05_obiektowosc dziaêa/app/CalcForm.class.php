<?php
class CalcForm {
	public $kwotaPozyczki;
	public $iloscMiesiecy;
	public $oprocentowanie;
} 