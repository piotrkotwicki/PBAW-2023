<?php

namespace app\forms;

class CalcForm {
    public $kwotaPozyczki;
    public $iloscMiesiecy;
    public $oprocentowanie;
} 