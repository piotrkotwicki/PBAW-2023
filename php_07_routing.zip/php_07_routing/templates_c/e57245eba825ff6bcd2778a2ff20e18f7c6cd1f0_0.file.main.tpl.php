<?php
/* Smarty version 4.3.0, created on 2023-05-16 01:06:06
  from 'C:\xampp\htdocs\php_07_routing\app\views\templates\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_6462badea3d9f5_71362435',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e57245eba825ff6bcd2778a2ff20e18f7c6cd1f0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_07_routing\\app\\views\\templates\\main.tpl',
      1 => 1684191857,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6462badea3d9f5_71362435 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
<head>
	<title>Kalkulator Kredytowy</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/main.css" />
	<noscript><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="page-wrapper">

	<!--	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4414169366462badea3c497_47216171', 'header');
?>
-->
	<!-- Header -->
	<header id="header" >
		<h1 id="logo"><a>Kalkulator Kredytowy</a></h1>
		<nav id="nav">
			<ul>
				<li>
				<li><a href="#app_top">Góra strony</a></li>
				<li><a href="#app_content">Idź do formularza</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
">Odśwież</a></li>
				<li><a  href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout">Wyloguj</a></li>
				</li>
			</ul>
		</nav>
	</header>

	<!-- Main -->
	<div id="main" class="wrapper style1">
		<div class="container">
			<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13964652546462badea3d4a0_18708655', 'content');
?>


			<!-- Footer -->
			<footer id="footer">
				<ul class="copyright">
					<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
				</ul>
			</footer>
		</div>
	</div>
</div>
</body>
</html>
<?php }
/* {block 'header'} */
class Block_4414169366462badea3c497_47216171 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'header' => 
  array (
    0 => 'Block_4414169366462badea3c497_47216171',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'header'} */
/* {block 'content'} */
class Block_13964652546462badea3d4a0_18708655 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_13964652546462badea3d4a0_18708655',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 Domyślna treść zawartości .... <?php
}
}
/* {/block 'content'} */
}
