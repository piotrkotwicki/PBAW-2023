<?php
/* Smarty version 4.3.0, created on 2023-05-16 01:06:06
  from 'C:\xampp\htdocs\php_07_routing\app\views\CalcView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_6462bade932ca6_92392358',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f3cf26c09d30360a056e0aaa32f121a7c251f925' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_07_routing\\app\\views\\CalcView.tpl',
      1 => 1684191857,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.tpl' => 1,
  ),
),false)) {
function content_6462bade932ca6_92392358 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12460608026462bade9235c2_99748904', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5939621676462bade924157_02372877', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'footer'} */
class Block_12460608026462bade9235c2_99748904 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_12460608026462bade9235c2_99748904',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
przykładowa tresć stopki wpisana do szablonu głównego z szablonu kalkulatora<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_5939621676462bade924157_02372877 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_5939621676462bade924157_02372877',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


	<!-- Main -->
	<div id="app_top" class="wrapper style1" href="#app_top">
	<div class="container">
	<header class="major">
		<h2>Kalkulator Kredytowy</h2>
		<p>Autor: Piotr Kotwicki</p>
	</header>

	<!-- Text -->
	<section id="app_content">
	<h3>O stronie</h3>
	<p>Kalkulator kredytowy w wersji obiektowej</p>
	<a  class="pure-button pure-button-primary" href="#app_content">Idź do formularza</a>
	<hr />

	<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
calcCompute" method="post">
		<fieldset>
			<label for="kwotaPozyczki">Kwota pożyczki: </label>
			<input id="kwotaPozyczki" type="text" placeholder="kwota pożyczki" name="kwotaPozyczki" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->kwotaPozyczki;?>
">
			<label for="iloscMiesiecy">Czas trwania w miesiącach: </label>
			<input id="iloscMiesiecy" type="text" placeholder="ilość miesięcy" name="iloscMiesiecy" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->iloscMiesiecy;?>
">
			<label for="oprocentowanie">Oprocentowanie: </label>
			<input id="oprocentowanie" type="text" placeholder="wartość oprocentowania" name="oprocentowanie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->oprocentowanie;?>
">

			<button type="submit" class="pure-button">Oblicz</button>
		</fieldset>
	</form>

	<?php $_smarty_tpl->_subTemplateRender('file:messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<?php if ((isset($_smarty_tpl->tpl_vars['res']->value->result))) {?>
		<div class="messages inf">
			Wynik: <?php echo $_smarty_tpl->tpl_vars['res']->value->result;?>

		</div>
	<?php }?>

<?php
}
}
/* {/block 'content'} */
}
